-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2023 at 01:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dymithra`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_post_user`
--

CREATE TABLE `add_post_user` (
  `post_id` int(11) NOT NULL,
  `text` varchar(500) NOT NULL,
  `image` longblob NOT NULL,
  `login_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_post_user`
--

INSERT INTO `add_post_user` (`post_id`, `text`, `image`, `login_id`, `date`, `time`) VALUES
(14, 'i love you dears', '', 0, '0000-00-00', '00:00:00'),
(15, 'my home sweet home', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(16, 'i love you all', '', 0, '0000-00-00', '00:00:00'),
(17, 'dfdfds', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(34, 'my seewty', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(35, 'my seewty', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(36, 'helloooooo my room is here', 0x494d475f32303233303730365f3133333833362e6a7067, 53, '0000-00-00', '00:00:00'),
(37, 'feeling good today', '', 0, '0000-00-00', '10:30:00'),
(38, 'my TV', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(39, 'feeling blessed to have a home like this', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(40, 'feeling so ', 0x494d475f32303233303730365f3133333833362e6a7067, 0, '0000-00-00', '00:00:00'),
(41, 'feeling good today', 0x70686f746f2d313531323536383430303631302d3632646132386263386131332e61766966, 0, '0000-00-00', '10:30:00'),
(42, ' good today', 0x70686f746f2d313531323536383430303631302d3632646132386263386131332e61766966, 0, '0000-00-00', '10:30:00'),
(55, 'MY SWEET HOME', 0x494d475f32303233303730365f3133333833362e6a7067, 53, '2023-07-07', '02:42 PM'),
(56, 'Happy to be in this world', '', 0, '0000-00-00', ''),
(57, 'this is a world full of good spirites', '', 53, '2023-07-07', '03:08 PM');

-- --------------------------------------------------------

--
-- Table structure for table `admin_tb`
--

CREATE TABLE `admin_tb` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_tb`
--

INSERT INTO `admin_tb` (`id`, `username`, `password`) VALUES
(1, '', ''),
(2, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `entertainment_tb`
--

CREATE TABLE `entertainment_tb` (
  `entr_id` int(11) NOT NULL,
  `link` varchar(250) NOT NULL,
  `caption` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entertainment_tb`
--

INSERT INTO `entertainment_tb` (`entr_id`, `link`, `caption`, `date`) VALUES
(1, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', 'malayalam', '0000-00-00'),
(2, 'https://www.youtube.com/watch?v=sSiA25XlG_A', 'Yoga Class', '0000-00-00'),
(3, 'https://www.youtube.com/watch?v=sSiA25XlG_A', 'Yoga Class', '0000-00-00'),
(4, 'https://www.youtube.com/watch?v=sSiA25XlG_A', 'Yoga Class Session2', '0000-00-00'),
(5, 'https://www.youtube.com/watch?v=sSiA25XlG_A', 'Yoga Class Session2', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `onlineclass_tb`
--

CREATE TABLE `onlineclass_tb` (
  `class_id` int(11) NOT NULL,
  `link` varchar(250) NOT NULL,
  `caption` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `onlineclass_tb`
--

INSERT INTO `onlineclass_tb` (`class_id`, `link`, `caption`, `date`) VALUES
(1, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', '0', '2023-06-28'),
(2, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', '0', '2023-06-28'),
(3, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', '0', '2023-06-28'),
(4, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', '0', '2023-06-28'),
(5, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', 'malayalam', '2023-06-28'),
(6, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', 'malayalam', '2023-06-28'),
(7, 'https://www.youtube.com/watch?v=TU1xedLQJ4E', 'malayalam', '2023-06-28'),
(8, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(9, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(10, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(11, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(12, 'fnhvv', 'bgcv', '2023-06-28'),
(13, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(14, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(15, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(16, 'fsfdsfdsfdsfdsf', 'dee', '2023-06-28'),
(17, 'fsfdsfdsfdsfdsf', 'dee', '0000-00-00'),
(18, 'fffffffffffffffff', 'dee', '0000-00-00'),
(19, 'fffffffffffffffff', 'dee', '2023-01-12'),
(20, 'https://www.youtube.com/watch?v=BKK5HuVyKaY', 'Hindi Class 10', '0000-00-00'),
(21, 'https://www.youtube.com/watch?v=BKK5HuVyKaY', 'Hindi Class 10', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `org_register`
--

CREATE TABLE `org_register` (
  `org_reg_id` int(11) NOT NULL,
  `org_category` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `contact_number` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `org_register`
--

INSERT INTO `org_register` (`org_reg_id`, `org_category`, `address`, `location`, `contact_number`, `email`, `login_id`) VALUES
(1, '', 'Rose villa', 'manjeri', 904567834, 'sddfd@gmail.com', 1),
(2, '', 'Rose villa', 'manjeri', 904567834, 'sddfd@gmail.com', 2),
(3, 'organisation', 'acvd villa', 'pmna', 45435323432, 'abc@gmail.com', 13),
(4, '', 'Rose villa', 'manjeri', 904567834, 'sddfd@gmail.com', 16),
(5, 'Public', 'Delhi Guest House, India ', 'Delhi', 9846332211, 'ambers@gmail.com', 17),
(6, 'private', 'asaapp', 'chennai', 525254, 'saf@gmail.com', 21),
(7, 'private', 'asaapp', 'chennai', 525254, 'saf@gmail.com', 22),
(8, 'Private', 'Villa Snowfall,london', 'UNited KIngdom', 987767558, 'dewdrops@gmail.com', 51),
(9, 'public', 'pmna house', 'manjeri', 5777557557, 'angels@gmail.com', 54),
(10, 'public', 'dewhouse', 'majneri', 67887687, 'dew@gmail.com', 55);

-- --------------------------------------------------------

--
-- Table structure for table `product_orders`
--

CREATE TABLE `product_orders` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `pickupdate` date NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(25) NOT NULL DEFAULT 'Requested'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_orders`
--

INSERT INTO `product_orders` (`order_id`, `product_id`, `user_id`, `type`, `rate`, `pickupdate`, `date`, `status`) VALUES
(1, 6, 0, '', 120, '0000-00-00', '2023-07-17', 'declined'),
(2, 7, 3, '', 100, '2023-04-04', '2023-07-17', 'declined'),
(3, 11, 3, '', 100, '2023-04-04', '2023-04-04', 'Requested'),
(4, 12, 32, '', 100, '0000-00-00', '2023-07-17', 'accepted'),
(5, 6, 32, '', 120, '2023-07-19', '2023-07-18', 'accepted'),
(6, 0, 0, '', 0, '0000-00-00', '0000-00-00', 'Requested'),
(7, 6, 0, '', 120, '2023-07-19', '2023-07-18', 'Requested'),
(8, 11, 0, '', 100, '2023-07-18', '2023-07-18', 'Requested'),
(9, 11, 0, '', 100, '2023-07-18', '2023-07-18', 'Requested'),
(10, 7, 53, '', 120, '2023-07-19', '2023-07-18', 'accepted'),
(11, 7, 53, '', 120, '2023-07-19', '2023-07-18', 'accepted'),
(12, 7, 53, '', 120, '2023-07-27', '2023-07-18', 'Requested'),
(13, 7, 53, '', 120, '2023-07-27', '2023-07-18', 'Requested'),
(14, 11, 53, '', 100, '2023-07-19', '2023-07-18', 'Requested'),
(15, 12, 53, '', 100, '2023-07-19', '2023-07-18', 'accepted'),
(16, 11, 53, '', 120, '2023-07-20', '2023-07-18', 'accepted'),
(17, 6, 53, '', 120, '2023-07-20', '2023-07-18', 'accepted'),
(18, 6, 53, '', 120, '2023-07-19', '2023-07-18', 'accepted'),
(19, 6, 53, '', 120, '2023-07-19', '2023-07-18', 'accepted'),
(20, 7, 53, '', 120, '2023-07-19', '2023-07-18', 'Requested'),
(21, 7, 53, '', 120, '2023-07-19', '2023-07-18', 'Requested'),
(22, 6, 53, '', 120, '2023-07-19', '2023-07-18', 'Requested'),
(23, 6, 53, '', 120, '2023-07-19', '2023-07-18', 'Requested'),
(24, 11, 53, '', 100, '2023-07-20', '2023-07-18', 'Requested'),
(25, 12, 32, '', 100, '2023-07-20', '2023-07-18', 'accepted'),
(26, 6, 53, '', 120, '2023-07-04', '2023-07-20', 'Requested'),
(27, 6, 53, '', 120, '2023-07-04', '2023-07-20', 'Requested');

-- --------------------------------------------------------

--
-- Table structure for table `product_tb`
--

CREATE TABLE `product_tb` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `image` longblob NOT NULL,
  `rate` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `modified_at` date NOT NULL,
  `org_reg_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_tb`
--

INSERT INTO `product_tb` (`product_id`, `product_name`, `description`, `image`, `rate`, `created_at`, `modified_at`, `org_reg_id`, `stock`) VALUES
(6, 'Wall hanger', 'A beautiful hanger with feathers', 0x494d475f32303233303731315f3134313634332e6a7067, 120, '2023-07-11', '2023-07-11', 0, 10),
(7, 'Wall hanger', 'A beautiful hanger with feathers', 0x494d475f32303233303731315f3134313634332e6a7067, 120, '2023-07-11', '2023-07-11', 0, 10),
(11, 'Wall hanger', 'A beautiful hanger with feathers', 0x494d475f32303233303731315f3134313634332e6a7067, 100, '2023-07-11', '2023-07-11', 0, 10),
(12, 'Wall hanger', 'A beautiful hanger with feathers', 0x494d475f32303233303731315f3134313634332e6a7067, 100, '2023-07-11', '2023-07-11', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `request_table`
--

CREATE TABLE `request_table` (
  `req_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `req_status` varchar(15) NOT NULL DEFAULT 'Requested',
  `description` varchar(500) NOT NULL,
  `image` text NOT NULL,
  `amount` int(11) NOT NULL,
  `foodtype` varchar(15) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `contact_address` varchar(100) NOT NULL,
  `contact_number` int(11) NOT NULL,
  `accepted_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request_table`
--

INSERT INTO `request_table` (`req_id`, `type`, `login_id`, `date`, `req_status`, `description`, `image`, `amount`, `foodtype`, `contact_name`, `contact_address`, `contact_number`, `accepted_id`) VALUES
(1, 'food', 53, '0000-00-00', 'Requested', 'delicious food', '', 100, 'veg', '0', '2049222', 0, 0),
(2, 'food', 5, '0000-00-00', 'Accepted', 'delicious food', '', 100, 'veg', '0', '2049222', 0, 0),
(3, 'food', 7, '0000-00-00', 'Accepted', 'delicious food', '', 100, 'veg', '0', '2049222', 0, 0),
(4, 'food', 4, '0000-00-00', 'Accepted', 'delicious food', '', 100, 'veg', '0', '2049222', 0, 0),
(5, 'food', 12, '0000-00-00', 'accepted', 'delicious food', '', 100, 'veg', '0', '2049222', 0, 0),
(6, 'food', 12, '0000-00-00', 'accepted', 'delicious food', 'photo-1514066558159-fc8c737ef259.avif', 100, 'veg', 'sam', '2049222', 0, 0),
(7, 'food', 12, '0000-00-00', 'accepted', 'delicious food', 'photo-1514066558159-fc8c737ef259.avif', 100, 'veg', 'sam', '2049222', 0, 0),
(8, 'food', 12, '2023-12-12', 'accepted', 'delicious food', 'photo-1514066558159-fc8c737ef259.avif', 100, 'veg', 'sam', '2049222', 0, 0),
(9, 'food', 12, '2023-12-12', 'accepted', 'delicious food', '', 100, 'veg', 'sam', '2049222', 0, 0),
(10, 'food', 12, '2023-12-12', 'accepted', 'delicious food', '', 100, 'veg', 'sam', '2049222', 0, 0),
(13, 'food', 13, '2023-12-12', 'accepted', 'delicious food', 'photo-1514066558159-fc8c737ef259.avif', 100, 'veg', 'sam', '2049222', 0, 0),
(15, 'food', 12, '0000-00-00', 'accepted', 'delicious food', '', 100, 'veg', 'sam', '2049222', 0, 0),
(16, 'clothes', 0, '0000-00-00', 'Accepted', 'jeans for 3 children of age 10', '', 0, '', 'ravi', '434354343', 0, 0),
(17, 'food', 12, '0000-00-00', 'Accepted', 'delicious food', '', 100, 'veg', 'sam', '2049222', 0, 0),
(18, 'clothes', 0, '0000-00-00', '', 'jeans for 3 children of age 10', '', 0, '', 'ravi', '434354343', 0, 0),
(19, 'money', 0, '0000-00-00', '', 'for medicinal purchase', '', 5000, '', '', '', 0, 0),
(20, 'accessories', 0, '0000-00-00', 'Accepted', '', '', 0, '', 'simon', '905563556', 0, 0),
(30, 'accessories', 0, '0000-00-00', 'Accepted', '', '', 0, '', 'shameer', '890012440', 0, 0),
(31, '', 0, '0000-00-00', '', '', '', 0, '', '', '', 0, 0),
(32, '', 0, '0000-00-00', '', '', '', 0, '', '', '', 0, 0),
(33, 'money', 0, '0000-00-00', 'Accepted', 'For book purchase', '', 5000, '', '', '', 0, 0),
(34, 'clothes', 0, '0000-00-00', 'Accepted', 'jeans and top', '', 0, '', 'samasw', '4353', 0, 0),
(35, 'medicine', 32, '0000-00-00', 'Accepted', 'medcine for cancer for 10 days', 'IMG_20230706_133836.jpg', 0, '', 'amazfds', '24232243', 0, 0),
(36, '', 53, '0000-00-00', 'Accepted', 'medcine for cancer for 10 days', 'IMG_20230706_133836.jpg', 0, '', 'amazfds', '24232243', 0, 0),
(38, '', 0, '0000-00-00', 'Requested', 'Medicine for fever', 'IMG_20230706_133836.jpg', 0, '', 'sameera', '45454534', 0, 0),
(39, 'medicine', 0, '0000-00-00', 'Requested', 'sds fsfas asdsa', 'IMG_20230706_133836.jpg', 0, '', 'sfdsf', '43432', 0, 0),
(40, 'accessories', 53, '0000-00-00', 'Accepted', '', '', 0, '', 'fgf', '5555555', 0, 0),
(41, 'others', 0, '0000-00-00', 'Requested', '', '', 0, '', 'sfdsfd', '4546', 0, 0),
(42, 'clothes', 0, '0000-00-00', 'Requested', 'fgfdg gfdgfd', '', 0, '', 'gfgfd', '3434324', 0, 0),
(43, 'others', 0, '0000-00-00', 'Requested', '', '', 0, '', 'dfgfdg', '543543', 0, 0),
(44, 'others', 32, '0000-00-00', 'Accepted', '', '', 0, '', 'fgfdg', '324343', 0, 0),
(45, 'clothes', 32, '0000-00-00', 'Requested', 'dsfsdfd', '', 0, '', 'dfdsfds', '4324324', 0, 0),
(46, 'medicine', 0, '0000-00-00', 'Requested', 'medicine for cough', 'IMG_20230706_133836.jpg', 0, '', 'ManojrPmna', '5454353454', 0, 0),
(47, 'money', 0, '0000-00-00', 'Accepted', 'for buying uniforms', '', 5000, '', '', '', 0, 0),
(48, 'clothes', 0, '0000-00-00', 'Accepted', 'jeans for 10 persons', '', 0, '', 'aman', '78799999', 0, 0),
(50, 'medicine', 0, '0000-00-00', 'Accepted', 'medicine for 10 days', 'IMG_20230706_133836.jpg', 0, '', 'maneesh', '2322432432', 0, 0),
(51, 'others', 32, '0000-00-00', 'Accepted', '', '', 0, '', 'anandhu', '4343434', 0, 0),
(53, 'medicine', 32, '0000-00-00', 'Requested', 'amazing day', 'IMG_20230706_133836.jpg', 0, '', 'Simran', '55663344', 0, 0),
(54, 'food', 0, '0000-00-00', 'Accepted', 'delicious food', '', 100, 'veg', 'sam', 'asdredd', 2049222, 0),
(55, 'money', 0, '0000-00-00', 'Accepted', 'for going on a trip', '', 5000, '', '', '', 0, 0),
(56, 'others', 53, '2023-07-07', 'Requested', '', '', 0, '', 'ammeeen', 'kunnakkav', 454354, 0),
(57, 'food', 0, '2023-07-07', 'Accepted', 'Meals for 10 persons', '', 0, 'nonveg', 'simon', 'rose villa', 2147483647, 0),
(58, 'medicine', 0, '2023-07-07', 'Accepted', 'Medicine for body pain for 10 days', 'IMG_20230706_133836.jpg', 0, '', 'anandhu', 'Manahattan house', 443343432, 0),
(59, 'others', 32, '2023-07-07', 'Accepted', '', '', 0, '', 'anaandh', 'anandhu house', 4324324, 0),
(60, 'accessories', 0, '2023-07-07', 'Accepted', '', '', 0, '', 'Sameera', 'sanuuz', 2147483647, 0),
(61, 'money', 0, '2023-07-10', 'Accepted', 'for abroad study application', '', 10000, '', '', '', 0, 0),
(62, 'clothes', 0, '2023-07-10', 'Accepted', 'jenas and top and kurthi', '', 0, '', 'dsds', 'gfdgfdgfd', 4342432, 0),
(63, 'accessories', 0, '2023-07-10', 'Accepted', '', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(64, 'accessories', 0, '2023-07-10', 'Accepted', '', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(65, 'accessories', 32, '2023-07-10', 'Accepted', '', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(66, 'accessories', 32, '2023-07-10', 'Accepted', '', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(67, 'accessories', 32, '2023-07-10', 'Accepted', '', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(68, 'accessories', 32, '2023-07-10', 'Accepted', '', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(69, 'accessories', 32, '2023-07-10', 'Accepted', 'Ruled book - 10,Unruled book-15', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(70, 'accessories', 32, '2023-07-10', 'Accepted', 'Ruled book - 10,Unruled book-15', '', 0, '', 'sharafudheen', 'malana', 785534333, 0),
(71, 'money', 32, '2023-07-12', 'Accepted', 'for medicinal purchase', '', 500, '', '', '', 0, 0),
(80, 'money', 32, '2023-07-12', 'Accepted', 'For admission purposes in loyalist college', '', 15000, '', '', '', 0, 0),
(81, 'money', 32, '2023-07-12', 'Accepted', 'Abroad universities application', '', 15000, '', '', '', 0, 0),
(82, 'food', 32, '2023-07-12', 'Accepted', 'CB for 50 persons', '', 0, 'veg', 'Aarathi', 'Aran valley', 5454543, 0),
(83, 'food', 53, '2023-07-12', 'Requested', 'Meals for 50 persons', '', 0, 'veg', 'Anandh', 'Aran valley', 5454543, 0),
(84, 'clothes', 32, '2023-07-12', 'Accepted', 'Shirts for a 10 year old boy Size :M', '', 0, '', 'Ameen', 'Silicon House', 2147483647, 0),
(85, 'accessories', 32, '2023-07-12', 'Accepted', 'Pencil Box', '', 0, '', 'Yamir', 'Mirrir house', 656546546, 0),
(86, 'medicine', 53, '2023-07-12', 'Requested', 'Medicine for 5 days', 'IMG_20230711_141643.jpg', 50, '', 'ashwathi', 'ameer house', 766867868, 0),
(87, 'clothes', 32, '2023-07-17', 'Accepted', 'clothes for childre', '', 0, '', 'aanadh', 'Ameer house', 3232322, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sponsor_reg`
--

CREATE TABLE `sponsor_reg` (
  `spo_reg_id` int(11) NOT NULL,
  `contact_number` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sponsor_reg`
--

INSERT INTO `sponsor_reg` (`spo_reg_id`, `contact_number`, `email`, `address`, `location`, `login_id`) VALUES
(1, 3232122, 'dcds@4343', '', 'pmna', 14),
(2, 3232122, 'dcds@4343', '', 'pmna', 15),
(3, 3232122, 'dcds@4343', '', 'pmna', 18),
(4, 3232122, 'dcds@4343', 'dfds', 'pmna', 19),
(5, 3232122, 'dcds@4343', '', 'pmna', 0),
(6, 3232122, 'dcds@4343', '', 'pmna', 0),
(7, 3232122, 'dcds@4343', '', 'pmna', 20),
(8, 963258, 'aabi@gmail.com', '', '', 23),
(9, 963258, 'aabi@gmail.com', '', '', 24),
(10, 963258, 'aabi@gmail.com', '', '', 25),
(11, 963258, 'aabi@gmail.com', '', '', 26),
(12, 963258, 'aabi@gmail.com', '', '', 27),
(13, 963258, 'aabi@gmail.com', '', '', 28),
(14, 963258, 'aabi@gmail.com', '', '', 29),
(15, 963258, 'aabi@gmail.com', '', '', 30),
(16, 963258, 'aabi@gmail.com', '', '', 31),
(17, 963258, 'aabi@gmail.com', '', '', 32),
(18, 963258, 'aabi@gmail.com', '', '', 33),
(19, 963258, 'aabi@gmail.com', '', '', 34),
(20, 963258, 'aabi@gmail.com', '', '', 35),
(21, 963258, 'aabi@gmail.com', '', '', 36),
(22, 963258, 'aabi@gmail.com', '', '', 37),
(23, 9632583424, 'aabi@gmail.com', '', '', 38),
(24, 9632583424, 'aabi@gmail.com', '', '', 39),
(25, 3232122, 'dcds@4343', '', 'pmna', 40),
(26, 9632583424, 'aabi@gmail.com', '', '', 41),
(27, 9633687907, '', '', '', 42),
(28, 9633687907, '', '', '', 43),
(29, 9633687907, '', '', '', 44),
(30, 9633687907, '', '', '', 45),
(31, 9633687907, '', '', '', 46),
(32, 9633687907, '', '', '', 47),
(33, 9633687907, '', '', '', 48),
(34, 9633687907, '', '', '', 49),
(35, 9633687907, '', '', '', 50),
(36, 98998877, 'sad@gmail.com', '', '', 52),
(37, 98998877, 'sad@gmail.com', '', '', 53),
(38, 78995334, 'anandhu123@gmail.con', '', '', 56),
(39, 5454354543, 'ym@gmail.com', '', '', 57),
(40, 434343243, 'aaa@gmail.com', '', '', 58);

-- --------------------------------------------------------

--
-- Table structure for table `spo_org_login`
--

CREATE TABLE `spo_org_login` (
  `sp_og_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `type` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `spo_org_login`
--

INSERT INTO `spo_org_login` (`sp_og_id`, `username`, `password`, `type`) VALUES
(1, 'heplers', '', ''),
(2, 'heplers', 'a242', 'sponsor'),
(3, 'helpers', 'a242', 'sponsor'),
(4, 'helpers', 'a242', 'sponsor'),
(5, '', '', ''),
(6, 'abc', 'abc123', 'organisation'),
(7, 'abc', 'abc123', 'organisation'),
(8, 'abc', 'abc123', 'organisation'),
(9, 'abc', 'abc123', 'organisation'),
(10, 'abc', 'abc123', 'organisation'),
(11, 'abc', 'abc123', 'organisation'),
(12, 'abc', 'abc123', 'organisation'),
(13, 'abc', 'abc123', 'organisation'),
(14, 'mm', 'mm123', ''),
(15, 'mm', 'mm123', 'sponsor'),
(16, 'heplers', '', ''),
(17, 'Amber', 'amber123', 'Organisation'),
(18, 'mm', 'mm123', 'sponsor'),
(19, 'reerewrew', 'mm123', 'sponsor'),
(20, 'mm', 'mm123', 'sponsor'),
(21, 'asap', 'saf123', 'Organisation'),
(22, 'asap', 'saf123', 'Organisation'),
(25, 'aabi', 'aabi123', 'sponsor'),
(26, 'aabi', 'aabi123', 'sponsor'),
(27, 'aabi', 'aabi123', 'sponsor'),
(28, 'aabi', 'aabi123', 'sponsor'),
(29, 'aabi', 'aabi123', 'sponsor'),
(30, 'aabi', 'aabi123', 'sponsor'),
(31, 'aabi', 'aabi123', 'sponsor'),
(32, 'aabi', 'aabi123', 'sponsor'),
(33, 'aabi1', 'aabi123', 'sponsor'),
(34, 'aabi1', 'aabi123', 'sponsor'),
(35, 'aabi1', 'aabi123', 'sponsor'),
(36, 'aabi1', 'aabi123', 'sponsor'),
(37, 'aabi1', 'aabi123', 'sponsor'),
(38, 'aabi1', 'aabi123', 'sponsor'),
(39, 'aabi1', 'aabi123', 'sponsor'),
(40, 'mm', 'mm123', 'sponsor'),
(41, 'aabi1', 'aabi123', 'sponsor'),
(42, '', 'aa123', ''),
(43, '', 'aa123', ''),
(44, '', 'aa123', ''),
(45, '', 'aa123', ''),
(46, '', 'aa123', ''),
(47, '', 'aa123', ''),
(48, '', 'aa123', ''),
(49, '', 'aa123', ''),
(50, '', 'aa123', ''),
(51, 'Dewdrops', 'dew123', 'Organisation'),
(52, 'sam', 'sam123', 'sponsor'),
(53, 'sam', 'sam123', 'sponsor'),
(54, 'angles', 'asdf', 'Organisation'),
(55, 'dewdrops', 'dew123', 'Organisation'),
(56, 'aarya', 'arya123', 'sponsor'),
(57, 'yamir', 'yamir123', 'sponsor'),
(58, 'sameer', 'sam123', 'sponsor');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `login_id` int(11) NOT NULL,
  `UDID` varchar(25) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(20) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`login_id`, `UDID`, `password`, `type`, `image`) VALUES
(53, 'QWERT', 'qwerty123', 'user', 0x706578656c732d6c756b61732d313431393933362e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `user_register_table`
--

CREATE TABLE `user_register_table` (
  `reg_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `contact_number` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register_table`
--

INSERT INTO `user_register_table` (`reg_id`, `name`, `contact_number`, `email`, `login_id`) VALUES
(47, 'amit', 0, '', 53);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_post_user`
--
ALTER TABLE `add_post_user`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `admin_tb`
--
ALTER TABLE `admin_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entertainment_tb`
--
ALTER TABLE `entertainment_tb`
  ADD PRIMARY KEY (`entr_id`);

--
-- Indexes for table `onlineclass_tb`
--
ALTER TABLE `onlineclass_tb`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `org_register`
--
ALTER TABLE `org_register`
  ADD PRIMARY KEY (`org_reg_id`);

--
-- Indexes for table `product_orders`
--
ALTER TABLE `product_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product_tb`
--
ALTER TABLE `product_tb`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `request_table`
--
ALTER TABLE `request_table`
  ADD PRIMARY KEY (`req_id`);

--
-- Indexes for table `sponsor_reg`
--
ALTER TABLE `sponsor_reg`
  ADD PRIMARY KEY (`spo_reg_id`);

--
-- Indexes for table `spo_org_login`
--
ALTER TABLE `spo_org_login`
  ADD PRIMARY KEY (`sp_og_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `user_register_table`
--
ALTER TABLE `user_register_table`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_post_user`
--
ALTER TABLE `add_post_user`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `admin_tb`
--
ALTER TABLE `admin_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `entertainment_tb`
--
ALTER TABLE `entertainment_tb`
  MODIFY `entr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `onlineclass_tb`
--
ALTER TABLE `onlineclass_tb`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `org_register`
--
ALTER TABLE `org_register`
  MODIFY `org_reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_orders`
--
ALTER TABLE `product_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `product_tb`
--
ALTER TABLE `product_tb`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `request_table`
--
ALTER TABLE `request_table`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `sponsor_reg`
--
ALTER TABLE `sponsor_reg`
  MODIFY `spo_reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `spo_org_login`
--
ALTER TABLE `spo_org_login`
  MODIFY `sp_og_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `user_register_table`
--
ALTER TABLE `user_register_table`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
